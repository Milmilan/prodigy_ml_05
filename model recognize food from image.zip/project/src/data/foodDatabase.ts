import { FoodItem } from '../types/food';

export const foodDatabase: FoodItem[] = [
  // Fruits
  {
    id: 'apple-red',
    name: 'Red Apple',
    caloriesPerGram: 0.52,
    protein: 0.3,
    carbs: 13.8,
    fat: 0.2,
    fiber: 2.4,
    category: 'Fruits',
    commonPortionSizes: [
      { name: 'Small apple', grams: 150 },
      { name: 'Medium apple', grams: 180 },
      { name: 'Large apple', grams: 220 }
    ]
  },
  {
    id: 'apple-green',
    name: 'Green Apple',
    caloriesPerGram: 0.58,
    protein: 0.4,
    carbs: 14.2,
    fat: 0.2,
    fiber: 2.8,
    category: 'Fruits',
    commonPortionSizes: [
      { name: 'Small apple', grams: 150 },
      { name: 'Medium apple', grams: 180 },
      { name: 'Large apple', grams: 220 }
    ]
  },
  {
    id: 'banana',
    name: 'Banana',
    caloriesPerGram: 0.89,
    protein: 1.1,
    carbs: 22.8,
    fat: 0.3,
    fiber: 2.6,
    category: 'Fruits',
    commonPortionSizes: [
      { name: 'Small banana', grams: 100 },
      { name: 'Medium banana', grams: 120 },
      { name: 'Large banana', grams: 150 }
    ]
  },
  {
    id: 'orange',
    name: 'Orange',
    caloriesPerGram: 0.47,
    protein: 0.9,
    carbs: 11.8,
    fat: 0.1,
    fiber: 2.4,
    category: 'Fruits',
    commonPortionSizes: [
      { name: 'Small orange', grams: 130 },
      { name: 'Medium orange', grams: 160 },
      { name: 'Large orange', grams: 200 }
    ]
  },
  {
    id: 'strawberries',
    name: 'Strawberries',
    caloriesPerGram: 0.32,
    protein: 0.7,
    carbs: 7.7,
    fat: 0.3,
    fiber: 2.0,
    category: 'Fruits',
    commonPortionSizes: [
      { name: 'Small serving', grams: 100 },
      { name: 'Medium serving', grams: 150 },
      { name: 'Large serving', grams: 200 }
    ]
  },
  {
    id: 'grapes',
    name: 'Grapes',
    caloriesPerGram: 0.69,
    protein: 0.6,
    carbs: 17.2,
    fat: 0.2,
    fiber: 0.9,
    category: 'Fruits',
    commonPortionSizes: [
      { name: 'Small bunch', grams: 80 },
      { name: 'Medium bunch', grams: 120 },
      { name: 'Large bunch', grams: 160 }
    ]
  },

  // Proteins
  {
    id: 'chicken-breast-grilled',
    name: 'Chicken Breast (Grilled)',
    caloriesPerGram: 1.65,
    protein: 31.0,
    carbs: 0,
    fat: 3.6,
    fiber: 0,
    category: 'Protein',
    commonPortionSizes: [
      { name: 'Small portion', grams: 100 },
      { name: 'Medium portion', grams: 150 },
      { name: 'Large portion', grams: 200 }
    ]
  },
  {
    id: 'chicken-thigh',
    name: 'Chicken Thigh',
    caloriesPerGram: 2.09,
    protein: 25.9,
    carbs: 0,
    fat: 10.9,
    fiber: 0,
    category: 'Protein',
    commonPortionSizes: [
      { name: 'Small thigh', grams: 80 },
      { name: 'Medium thigh', grams: 120 },
      { name: 'Large thigh', grams: 160 }
    ]
  },
  {
    id: 'salmon-grilled',
    name: 'Salmon (Grilled)',
    caloriesPerGram: 2.06,
    protein: 25.4,
    carbs: 0,
    fat: 12.4,
    fiber: 0,
    category: 'Protein',
    commonPortionSizes: [
      { name: 'Small fillet', grams: 100 },
      { name: 'Medium fillet', grams: 140 },
      { name: 'Large fillet', grams: 180 }
    ]
  },
  {
    id: 'tuna-steak',
    name: 'Tuna Steak',
    caloriesPerGram: 1.44,
    protein: 30.0,
    carbs: 0,
    fat: 4.9,
    fiber: 0,
    category: 'Protein',
    commonPortionSizes: [
      { name: 'Small steak', grams: 120 },
      { name: 'Medium steak', grams: 160 },
      { name: 'Large steak', grams: 200 }
    ]
  },
  {
    id: 'beef-steak',
    name: 'Beef Steak',
    caloriesPerGram: 2.71,
    protein: 26.1,
    carbs: 0,
    fat: 17.0,
    fiber: 0,
    category: 'Protein',
    commonPortionSizes: [
      { name: 'Small steak', grams: 150 },
      { name: 'Medium steak', grams: 200 },
      { name: 'Large steak', grams: 300 }
    ]
  },
  {
    id: 'eggs-scrambled',
    name: 'Scrambled Eggs',
    caloriesPerGram: 1.49,
    protein: 10.6,
    carbs: 1.6,
    fat: 10.4,
    fiber: 0,
    category: 'Protein',
    commonPortionSizes: [
      { name: '1 egg', grams: 50 },
      { name: '2 eggs', grams: 100 },
      { name: '3 eggs', grams: 150 }
    ]
  },

  // Grains & Carbs
  {
    id: 'white-rice-cooked',
    name: 'White Rice (Cooked)',
    caloriesPerGram: 1.30,
    protein: 2.7,
    carbs: 28.0,
    fat: 0.3,
    fiber: 0.4,
    category: 'Grains',
    commonPortionSizes: [
      { name: 'Small serving', grams: 80 },
      { name: 'Medium serving', grams: 120 },
      { name: 'Large serving', grams: 160 }
    ]
  },
  {
    id: 'brown-rice-cooked',
    name: 'Brown Rice (Cooked)',
    caloriesPerGram: 1.12,
    protein: 2.6,
    carbs: 22.0,
    fat: 0.9,
    fiber: 1.8,
    category: 'Grains',
    commonPortionSizes: [
      { name: 'Small serving', grams: 80 },
      { name: 'Medium serving', grams: 120 },
      { name: 'Large serving', grams: 160 }
    ]
  },
  {
    id: 'pasta-cooked',
    name: 'Pasta (Cooked)',
    caloriesPerGram: 1.31,
    protein: 5.0,
    carbs: 25.0,
    fat: 1.1,
    fiber: 1.8,
    category: 'Grains',
    commonPortionSizes: [
      { name: 'Small serving', grams: 85 },
      { name: 'Medium serving', grams: 125 },
      { name: 'Large serving', grams: 165 }
    ]
  },
  {
    id: 'quinoa-cooked',
    name: 'Quinoa (Cooked)',
    caloriesPerGram: 1.20,
    protein: 4.4,
    carbs: 21.3,
    fat: 1.9,
    fiber: 2.8,
    category: 'Grains',
    commonPortionSizes: [
      { name: 'Small serving', grams: 90 },
      { name: 'Medium serving', grams: 130 },
      { name: 'Large serving', grams: 170 }
    ]
  },
  {
    id: 'bread-whole-wheat',
    name: 'Whole Wheat Bread',
    caloriesPerGram: 2.47,
    protein: 13.2,
    carbs: 41.3,
    fat: 4.2,
    fiber: 6.0,
    category: 'Grains',
    commonPortionSizes: [
      { name: '1 slice', grams: 28 },
      { name: '2 slices', grams: 56 },
      { name: '3 slices', grams: 84 }
    ]
  },

  // Vegetables
  {
    id: 'broccoli',
    name: 'Broccoli',
    caloriesPerGram: 0.34,
    protein: 2.8,
    carbs: 7.0,
    fat: 0.4,
    fiber: 2.6,
    category: 'Vegetables',
    commonPortionSizes: [
      { name: 'Small serving', grams: 80 },
      { name: 'Medium serving', grams: 120 },
      { name: 'Large serving', grams: 180 }
    ]
  },
  {
    id: 'spinach',
    name: 'Spinach',
    caloriesPerGram: 0.23,
    protein: 2.9,
    carbs: 3.6,
    fat: 0.4,
    fiber: 2.2,
    category: 'Vegetables',
    commonPortionSizes: [
      { name: 'Small serving', grams: 60 },
      { name: 'Medium serving', grams: 100 },
      { name: 'Large serving', grams: 150 }
    ]
  },
  {
    id: 'carrots',
    name: 'Carrots',
    caloriesPerGram: 0.41,
    protein: 0.9,
    carbs: 9.6,
    fat: 0.2,
    fiber: 2.8,
    category: 'Vegetables',
    commonPortionSizes: [
      { name: 'Small carrot', grams: 60 },
      { name: 'Medium carrot', grams: 80 },
      { name: 'Large carrot', grams: 120 }
    ]
  },
  {
    id: 'bell-pepper',
    name: 'Bell Pepper',
    caloriesPerGram: 0.31,
    protein: 1.0,
    carbs: 7.3,
    fat: 0.3,
    fiber: 2.5,
    category: 'Vegetables',
    commonPortionSizes: [
      { name: 'Small pepper', grams: 100 },
      { name: 'Medium pepper', grams: 140 },
      { name: 'Large pepper', grams: 180 }
    ]
  },
  {
    id: 'tomato',
    name: 'Tomato',
    caloriesPerGram: 0.18,
    protein: 0.9,
    carbs: 3.9,
    fat: 0.2,
    fiber: 1.2,
    category: 'Vegetables',
    commonPortionSizes: [
      { name: 'Small tomato', grams: 90 },
      { name: 'Medium tomato', grams: 120 },
      { name: 'Large tomato', grams: 180 }
    ]
  },

  // Fast Food & Processed
  {
    id: 'pizza-margherita',
    name: 'Margherita Pizza Slice',
    caloriesPerGram: 2.66,
    protein: 11.0,
    carbs: 33.0,
    fat: 10.0,
    fiber: 2.3,
    category: 'Fast Food',
    commonPortionSizes: [
      { name: 'Thin slice', grams: 80 },
      { name: 'Regular slice', grams: 120 },
      { name: 'Thick slice', grams: 160 }
    ]
  },
  {
    id: 'pizza-pepperoni',
    name: 'Pepperoni Pizza Slice',
    caloriesPerGram: 2.98,
    protein: 12.2,
    carbs: 35.7,
    fat: 13.2,
    fiber: 2.3,
    category: 'Fast Food',
    commonPortionSizes: [
      { name: 'Thin slice', grams: 85 },
      { name: 'Regular slice', grams: 125 },
      { name: 'Thick slice', grams: 165 }
    ]
  },
  {
    id: 'hamburger',
    name: 'Hamburger',
    caloriesPerGram: 2.95,
    protein: 17.2,
    carbs: 28.0,
    fat: 15.4,
    fiber: 2.1,
    category: 'Fast Food',
    commonPortionSizes: [
      { name: 'Small burger', grams: 120 },
      { name: 'Medium burger', grams: 180 },
      { name: 'Large burger', grams: 240 }
    ]
  },
  {
    id: 'french-fries',
    name: 'French Fries',
    caloriesPerGram: 3.65,
    protein: 4.0,
    carbs: 43.0,
    fat: 17.0,
    fiber: 3.8,
    category: 'Fast Food',
    commonPortionSizes: [
      { name: 'Small fries', grams: 70 },
      { name: 'Medium fries', grams: 115 },
      { name: 'Large fries', grams: 150 }
    ]
  },

  // Dairy
  {
    id: 'greek-yogurt',
    name: 'Greek Yogurt',
    caloriesPerGram: 0.59,
    protein: 10.0,
    carbs: 3.6,
    fat: 0.4,
    fiber: 0,
    category: 'Dairy',
    commonPortionSizes: [
      { name: 'Small cup', grams: 150 },
      { name: 'Medium cup', grams: 200 },
      { name: 'Large cup', grams: 250 }
    ]
  },
  {
    id: 'milk-whole',
    name: 'Whole Milk',
    caloriesPerGram: 0.61,
    protein: 3.2,
    carbs: 4.8,
    fat: 3.3,
    fiber: 0,
    category: 'Dairy',
    commonPortionSizes: [
      { name: 'Small glass', grams: 200 },
      { name: 'Medium glass', grams: 250 },
      { name: 'Large glass', grams: 300 }
    ]
  },
  {
    id: 'cheese-cheddar',
    name: 'Cheddar Cheese',
    caloriesPerGram: 4.03,
    protein: 25.0,
    carbs: 1.3,
    fat: 33.1,
    fiber: 0,
    category: 'Dairy',
    commonPortionSizes: [
      { name: 'Small slice', grams: 20 },
      { name: 'Medium slice', grams: 30 },
      { name: 'Large slice', grams: 40 }
    ]
  },

  // Nuts & Seeds
  {
    id: 'almonds',
    name: 'Almonds',
    caloriesPerGram: 5.79,
    protein: 21.2,
    carbs: 21.6,
    fat: 49.9,
    fiber: 12.5,
    category: 'Nuts & Seeds',
    commonPortionSizes: [
      { name: 'Small handful', grams: 20 },
      { name: 'Medium handful', grams: 30 },
      { name: 'Large handful', grams: 40 }
    ]
  },
  {
    id: 'walnuts',
    name: 'Walnuts',
    caloriesPerGram: 6.54,
    protein: 15.2,
    carbs: 13.7,
    fat: 65.2,
    fiber: 6.7,
    category: 'Nuts & Seeds',
    commonPortionSizes: [
      { name: 'Small handful', grams: 20 },
      { name: 'Medium handful', grams: 30 },
      { name: 'Large handful', grams: 40 }
    ]
  }
];

// Enhanced food recognition keywords for better matching
export const foodKeywords: { [key: string]: string[] } = {
  'apple-red': ['red apple', 'apple red', 'red delicious', 'gala apple'],
  'apple-green': ['green apple', 'granny smith', 'apple green'],
  'banana': ['banana', 'bananas', 'yellow banana'],
  'orange': ['orange', 'oranges', 'citrus'],
  'strawberries': ['strawberry', 'strawberries', 'berry', 'berries'],
  'grapes': ['grape', 'grapes', 'grape bunch'],
  'chicken-breast-grilled': ['chicken breast', 'grilled chicken', 'chicken fillet'],
  'chicken-thigh': ['chicken thigh', 'chicken leg', 'dark meat chicken'],
  'salmon-grilled': ['salmon', 'grilled salmon', 'salmon fillet'],
  'tuna-steak': ['tuna', 'tuna steak', 'ahi tuna'],
  'beef-steak': ['beef', 'steak', 'beef steak', 'sirloin'],
  'eggs-scrambled': ['scrambled eggs', 'eggs', 'egg'],
  'white-rice-cooked': ['white rice', 'rice', 'steamed rice'],
  'brown-rice-cooked': ['brown rice', 'whole grain rice'],
  'pasta-cooked': ['pasta', 'spaghetti', 'noodles'],
  'quinoa-cooked': ['quinoa', 'quinoa grain'],
  'bread-whole-wheat': ['bread', 'whole wheat bread', 'toast'],
  'broccoli': ['broccoli', 'green vegetable'],
  'spinach': ['spinach', 'leafy greens'],
  'carrots': ['carrot', 'carrots', 'orange vegetable'],
  'bell-pepper': ['bell pepper', 'pepper', 'capsicum'],
  'tomato': ['tomato', 'tomatoes', 'red tomato'],
  'pizza-margherita': ['pizza', 'margherita pizza', 'cheese pizza'],
  'pizza-pepperoni': ['pepperoni pizza', 'pizza pepperoni'],
  'hamburger': ['burger', 'hamburger', 'cheeseburger'],
  'french-fries': ['fries', 'french fries', 'potato fries'],
  'greek-yogurt': ['yogurt', 'greek yogurt', 'yoghurt'],
  'milk-whole': ['milk', 'whole milk'],
  'cheese-cheddar': ['cheese', 'cheddar', 'cheddar cheese'],
  'almonds': ['almond', 'almonds', 'nuts'],
  'walnuts': ['walnut', 'walnuts', 'nuts']
};