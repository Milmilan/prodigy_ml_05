import React, { useState, useEffect } from 'react';
import { Search, Plus } from 'lucide-react';
import { searchFoodByName } from '../services/foodRecognition';
import { FoodItem, RecognizedFood } from '../types/food';

interface FoodSearchProps {
  onAddFood: (food: RecognizedFood, meal: string) => void;
}

export const FoodSearch: React.FC<FoodSearchProps> = ({ onAddFood }) => {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<FoodItem[]>([]);
  const [selectedMeal, setSelectedMeal] = useState('lunch');
  const [selectedWeight, setSelectedWeight] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    if (query.length > 2) {
      const results = searchFoodByName(query);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  }, [query]);

  const handleAddFood = (foodItem: FoodItem) => {
    const weight = selectedWeight[foodItem.id] || foodItem.commonPortionSizes[1]?.grams || 100;
    const calories = Math.round(foodItem.caloriesPerGram * weight);
    
    const recognizedFood: RecognizedFood = {
      foodItem,
      confidence: 1.0, // Manual entry has 100% confidence
      estimatedWeight: weight,
      calories,
      nutrition: {
        protein: Math.round(foodItem.protein * (weight / 100) * 10) / 10,
        carbs: Math.round(foodItem.carbs * (weight / 100) * 10) / 10,
        fat: Math.round(foodItem.fat * (weight / 100) * 10) / 10,
        fiber: Math.round(foodItem.fiber * (weight / 100) * 10) / 10
      }
    };

    onAddFood(recognizedFood, selectedMeal);
    setQuery('');
    setSearchResults([]);
  };

  const handleWeightChange = (foodId: string, weight: number) => {
    setSelectedWeight(prev => ({ ...prev, [foodId]: weight }));
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <Search className="h-5 w-5 text-emerald-600" />
        <span>Manual Food Search</span>
      </h3>

      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search for food items..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <select
          value={selectedMeal}
          onChange={(e) => setSelectedMeal(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
        >
          <option value="breakfast">🥞 Breakfast</option>
          <option value="lunch">🥗 Lunch</option>
          <option value="dinner">🍽️ Dinner</option>
          <option value="snack">🍎 Snack</option>
        </select>

        {searchResults.length > 0 && (
          <div className="max-h-96 overflow-y-auto space-y-2">
            {searchResults.map((food) => {
              const weight = selectedWeight[food.id] || food.commonPortionSizes[1]?.grams || 100;
              const calories = Math.round(food.caloriesPerGram * weight);
              
              return (
                <div key={food.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-gray-900">{food.name}</h4>
                      <p className="text-sm text-gray-600">{food.category}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-emerald-600">{calories}</div>
                      <div className="text-xs text-gray-600">calories</div>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Weight: {weight}g
                    </label>
                    <input
                      type="range"
                      min="10"
                      max="500"
                      step="10"
                      value={weight}
                      onChange={(e) => handleWeightChange(food.id, parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>10g</span>
                      <span>500g</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2 mb-3 text-xs">
                    <div className="text-center p-2 bg-blue-50 rounded">
                      <div className="font-medium text-blue-600">
                        {Math.round(food.protein * (weight / 100) * 10) / 10}g
                      </div>
                      <div className="text-gray-600">Protein</div>
                    </div>
                    <div className="text-center p-2 bg-yellow-50 rounded">
                      <div className="font-medium text-yellow-600">
                        {Math.round(food.carbs * (weight / 100) * 10) / 10}g
                      </div>
                      <div className="text-gray-600">Carbs</div>
                    </div>
                    <div className="text-center p-2 bg-red-50 rounded">
                      <div className="font-medium text-red-600">
                        {Math.round(food.fat * (weight / 100) * 10) / 10}g
                      </div>
                      <div className="text-gray-600">Fat</div>
                    </div>
                    <div className="text-center p-2 bg-green-50 rounded">
                      <div className="font-medium text-green-600">
                        {Math.round(food.fiber * (weight / 100) * 10) / 10}g
                      </div>
                      <div className="text-gray-600">Fiber</div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleAddFood(food)}
                    className="w-full px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Add to {selectedMeal}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {query.length > 2 && searchResults.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Search className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No foods found matching "{query}"</p>
            <p className="text-sm">Try searching for common food names like "chicken", "apple", or "rice"</p>
          </div>
        )}
      </div>
    </div>
  );
};