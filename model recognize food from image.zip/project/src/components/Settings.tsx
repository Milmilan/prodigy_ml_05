import React, { useState } from 'react';
import { Target, Download, Trash2 } from 'lucide-react';

interface SettingsProps {
  dailyGoal: number;
  onUpdateGoal: (goal: number) => void;
  loggedFoods: any[];
}

export const Settings: React.FC<SettingsProps> = ({ dailyGoal, onUpdateGoal, loggedFoods }) => {
  const [goalInput, setGoalInput] = useState(dailyGoal.toString());
  const [showConfirm, setShowConfirm] = useState(false);

  const handleSaveGoal = () => {
    const newGoal = parseInt(goalInput);
    if (newGoal > 0 && newGoal <= 5000) {
      onUpdateGoal(newGoal);
    }
  };

  const exportData = () => {
    const data = JSON.stringify(loggedFoods, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `food-log-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearAllData = () => {
    localStorage.removeItem('foodLog');
    localStorage.removeItem('dailyCalorieGoal');
    window.location.reload();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Settings</h2>

      {/* Daily Goal Setting */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Target className="h-6 w-6 text-emerald-600" />
          <h3 className="text-lg font-semibold text-gray-900">Daily Calorie Goal</h3>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Target calories per day
            </label>
            <div className="flex items-center space-x-3">
              <input
                type="number"
                min="1000"
                max="5000"
                step="50"
                value={goalInput}
                onChange={(e) => setGoalInput(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
              <button
                onClick={handleSaveGoal}
                className="px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-2 text-sm">
            <button
              onClick={() => setGoalInput('1800')}
              className="px-3 py-2 bg-gray-100 hover:bg-emerald-100 text-gray-700 hover:text-emerald-700 rounded-lg transition-colors"
            >
              Weight Loss<br />1800 cal
            </button>
            <button
              onClick={() => setGoalInput('2200')}
              className="px-3 py-2 bg-gray-100 hover:bg-emerald-100 text-gray-700 hover:text-emerald-700 rounded-lg transition-colors"
            >
              Maintenance<br />2200 cal
            </button>
            <button
              onClick={() => setGoalInput('2800')}
              className="px-3 py-2 bg-gray-100 hover:bg-emerald-100 text-gray-700 hover:text-emerald-700 rounded-lg transition-colors"
            >
              Weight Gain<br />2800 cal
            </button>
          </div>
        </div>
      </div>

      {/* Data Management */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Data Management</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <div className="font-medium text-gray-900">Export Data</div>
              <div className="text-sm text-gray-600">Download your food log as JSON</div>
            </div>
            <button
              onClick={exportData}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2"
            >
              <Download className="h-4 w-4" />
              <span>Export</span>
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg border border-red-200">
            <div>
              <div className="font-medium text-red-900">Clear All Data</div>
              <div className="text-sm text-red-600">Delete all logged foods and settings</div>
            </div>
            {!showConfirm ? (
              <button
                onClick={() => setShowConfirm(true)}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors flex items-center space-x-2"
              >
                <Trash2 className="h-4 w-4" />
                <span>Clear</span>
              </button>
            ) : (
              <div className="space-x-2">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="px-3 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={clearAllData}
                  className="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors text-sm"
                >
                  Confirm
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* App Info */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">About</h3>
        <div className="space-y-2 text-sm text-gray-600">
          <p><strong>FoodCalorie AI</strong> - Advanced Food Recognition & Calorie Tracking</p>
          <p>Version 1.0.0</p>
          <p>Total logged foods: {loggedFoods.length}</p>
          <p>Built with React, TypeScript, and AI-powered food recognition</p>
        </div>
      </div>
    </div>
  );
};