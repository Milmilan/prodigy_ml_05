import React, { useState } from 'react';
import { RecognizedFood } from '../types/food';
import { Check, Edit, Utensils, Search, TrendingUp } from 'lucide-react';
import { adjustPortionSize } from '../services/foodRecognition';

interface FoodResultsProps {
  results: RecognizedFood[];
  onAddFood: (food: RecognizedFood, meal: string) => void;
}

export const FoodResults: React.FC<FoodResultsProps> = ({ results, onAddFood }) => {
  const [selectedMeals, setSelectedMeals] = useState<{ [key: string]: string }>({});
  const [adjustedResults, setAdjustedResults] = useState<RecognizedFood[]>(results);
  const [editingWeights, setEditingWeights] = useState<{ [key: string]: boolean }>({});
  const [showConfidenceDetails, setShowConfidenceDetails] = useState<{ [key: string]: boolean }>({});

  const handleWeightChange = (index: number, newWeight: number) => {
    const updated = [...adjustedResults];
    updated[index] = adjustPortionSize(updated[index], newWeight);
    setAdjustedResults(updated);
  };

  const handleAddFood = (food: RecognizedFood, index: number) => {
    const meal = selectedMeals[index] || 'lunch';
    onAddFood(food, meal);
    
    // Reset selection
    const newMeals = { ...selectedMeals };
    delete newMeals[index];
    setSelectedMeals(newMeals);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Food Recognition Results</h2>
        <p className="text-gray-600">Review and adjust the detected foods before adding to your log</p>
      </div>

      <div className="space-y-4">
        {adjustedResults.map((result, index) => (
          <div key={index} className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h3 className="text-xl font-semibold text-gray-900">{result.foodItem.name}</h3>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      result.confidence >= 0.9 
                        ? 'bg-green-100 text-green-800' 
                        : result.confidence >= 0.8 
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-orange-100 text-orange-800'
                    }`}>
                      {Math.round(result.confidence * 100)}% confident
                    </span>
                    <button
                      onClick={() => setShowConfidenceDetails(prev => ({ ...prev, [index]: !prev[index] }))}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <TrendingUp className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <p className="text-gray-600 text-sm">{result.foodItem.category}</p>
                
                {/* Confidence Details */}
                {showConfidenceDetails[index] && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="text-sm font-medium text-blue-900 mb-2">Recognition Details</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-blue-700">Base Confidence:</span>
                        <span className="font-medium">{Math.round(result.confidence * 100)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-blue-700">Image Quality:</span>
                        <span className="font-medium">High</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-blue-700">Food Visibility:</span>
                        <span className="font-medium">Clear</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-blue-700">Lighting:</span>
                        <span className="font-medium">Good</span>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-blue-600">
                      {result.confidence >= 0.9 
                        ? "✓ High accuracy - Very confident in this identification"
                        : result.confidence >= 0.8 
                        ? "⚠ Good accuracy - Fairly confident, please verify"
                        : "⚠ Moderate accuracy - Please double-check this identification"
                      }
                    </div>
                  </div>
                )}
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold text-emerald-600">{result.calories}</div>
                <div className="text-sm text-gray-600">calories</div>
              </div>
            </div>

            {/* Weight Adjustment */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-700">Estimated Weight</label>
                <button
                  onClick={() => setEditingWeights(prev => ({ ...prev, [index]: !prev[index] }))}
                  className="text-emerald-600 hover:text-emerald-700 text-sm flex items-center space-x-1"
                >
                  <Edit className="h-4 w-4" />
                  <span>Adjust</span>
                </button>
              </div>
              
              {editingWeights[index] ? (
                <div className="space-y-3">
                  <input
                    type="range"
                    min="50"
                    max="500"
                    step="10"
                    value={result.estimatedWeight}
                    onChange={(e) => handleWeightChange(index, parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>50g</span>
                    <span className="font-medium text-gray-900">{result.estimatedWeight}g</span>
                    <span>500g</span>
                  </div>
                  
                  {/* Common portion sizes */}
                  <div className="grid grid-cols-3 gap-2">
                    {result.foodItem.commonPortionSizes.map((portion, pIndex) => (
                      <button
                        key={pIndex}
                        onClick={() => handleWeightChange(index, portion.grams)}
                        className="px-3 py-2 text-xs bg-gray-100 hover:bg-emerald-100 text-gray-700 hover:text-emerald-700 rounded-lg transition-colors"
                      >
                        {portion.name}
                        <br />
                        <span className="font-medium">{portion.grams}g</span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-lg font-medium text-gray-900">{result.estimatedWeight}g</div>
              )}
            </div>

            {/* Nutrition Info */}
            <div className="grid grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 rounded-lg">
              <div className="text-center">
                <div className="text-lg font-semibold text-blue-600">{result.nutrition.protein}g</div>
                <div className="text-xs text-gray-600">Protein</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-yellow-600">{result.nutrition.carbs}g</div>
                <div className="text-xs text-gray-600">Carbs</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-red-600">{result.nutrition.fat}g</div>
                <div className="text-xs text-gray-600">Fat</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-green-600">{result.nutrition.fiber}g</div>
                <div className="text-xs text-gray-600">Fiber</div>
              </div>
            </div>

            {/* Meal Selection and Add Button */}
            <div className="flex items-center justify-between">
              <select
                value={selectedMeals[index] || 'lunch'}
                onChange={(e) => setSelectedMeals(prev => ({ ...prev, [index]: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              >
                <option value="breakfast">🥞 Breakfast</option>
                <option value="lunch">🥗 Lunch</option>
                <option value="dinner">🍽️ Dinner</option>
                <option value="snack">🍎 Snack</option>
              </select>
              
              <button
                onClick={() => handleAddFood(result, index)}
                className="px-6 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors flex items-center space-x-2"
              >
                <Check className="h-4 w-4" />
                <span>Add to Log</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};