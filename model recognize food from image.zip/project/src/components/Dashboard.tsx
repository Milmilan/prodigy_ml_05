import React from 'react';
import { DailyStats, LoggedFood } from '../types/food';
import { Target, TrendingUp, Award, Flame } from 'lucide-react';

interface DashboardProps {
  dailyStats: DailyStats;
  foodsByMeal: {
    breakfast: LoggedFood[];
    lunch: LoggedFood[];
    dinner: LoggedFood[];
    snack: LoggedFood[];
  };
  onRemoveFood: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ dailyStats, foodsByMeal, onRemoveFood }) => {
  const calorieProgress = (dailyStats.totalCalories / dailyStats.goalCalories) * 100;
  const isOverGoal = calorieProgress > 100;

  const mealIcons = {
    breakfast: '🥞',
    lunch: '🥗',
    dinner: '🍽️',
    snack: '🍎'
  };

  return (
    <div className="space-y-6">
      {/* Daily Overview */}
      <div className="bg-gradient-to-r from-emerald-500 to-blue-500 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Today's Progress</h2>
          <div className="flex items-center space-x-2">
            <Flame className="h-6 w-6" />
            <span className="text-xl font-semibold">{dailyStats.totalCalories}</span>
            <span className="text-emerald-100">/ {dailyStats.goalCalories} cal</span>
          </div>
        </div>
        
        <div className="w-full bg-white bg-opacity-20 rounded-full h-3 mb-4">
          <div 
            className={`h-3 rounded-full transition-all duration-500 ${
              isOverGoal ? 'bg-yellow-300' : 'bg-white'
            }`}
            style={{ width: `${Math.min(calorieProgress, 100)}%` }}
          />
        </div>
        
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold">{Math.round(dailyStats.totalProtein)}g</div>
            <div className="text-emerald-100 text-sm">Protein</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{Math.round(dailyStats.totalCarbs)}g</div>
            <div className="text-emerald-100 text-sm">Carbs</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{Math.round(dailyStats.totalFat)}g</div>
            <div className="text-emerald-100 text-sm">Fat</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{Math.round(dailyStats.totalFiber)}g</div>
            <div className="text-emerald-100 text-sm">Fiber</div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <Target className="h-6 w-6 text-emerald-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{Math.round(calorieProgress)}%</div>
              <div className="text-sm text-gray-600">Goal Progress</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <TrendingUp className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">
                {Object.values(foodsByMeal).flat().length}
              </div>
              <div className="text-sm text-gray-600">Items Logged</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <Award className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">
                {dailyStats.goalCalories - dailyStats.totalCalories > 0 ? 
                  dailyStats.goalCalories - dailyStats.totalCalories : 0}
              </div>
              <div className="text-sm text-gray-600">Calories Left</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Flame className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">
                {Math.round((dailyStats.totalProtein * 4 + dailyStats.totalCarbs * 4 + dailyStats.totalFat * 9) / dailyStats.totalCalories * 100) || 0}%
              </div>
              <div className="text-sm text-gray-600">Macro Balance</div>
            </div>
          </div>
        </div>
      </div>

      {/* Meals Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {Object.entries(foodsByMeal).map(([meal, foods]) => (
          <div key={meal} className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
              <span>{mealIcons[meal as keyof typeof mealIcons]}</span>
              <span className="capitalize">{meal}</span>
              <span className="text-sm text-gray-500">
                ({foods.reduce((sum, food) => sum + food.recognizedFood.calories, 0)} cal)
              </span>
            </h3>
            
            {foods.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No items logged for this meal</p>
            ) : (
              <div className="space-y-3">
                {foods.map((food) => (
                  <div key={food.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <div className="font-medium text-gray-900">{food.recognizedFood.foodItem.name}</div>
                      <div className="text-sm text-gray-600">
                        {food.adjustedWeight || food.recognizedFood.estimatedWeight}g • 
                        {food.recognizedFood.calories} cal
                      </div>
                    </div>
                    <button
                      onClick={() => onRemoveFood(food.id)}
                      className="text-red-500 hover:text-red-700 text-sm px-2 py-1 rounded hover:bg-red-50 transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};