import React, { useState, useRef } from 'react';
import { Camera, Upload, Loader2 } from 'lucide-react';

interface ImageUploadProps {
  onImageUpload: (file: File) => void;
  isLoading: boolean;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({ onImageUpload, isLoading }) => {
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files[0] && files[0].type.startsWith('image/')) {
      onImageUpload(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
          dragOver
            ? 'border-emerald-400 bg-emerald-50'
            : 'border-gray-300 hover:border-emerald-400 hover:bg-gray-50'
        } ${isLoading ? 'pointer-events-none opacity-60' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {isLoading ? (
          <div className="flex flex-col items-center space-y-4">
            <Loader2 className="h-12 w-12 text-emerald-500 animate-spin" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Analyzing your food...</h3>
              <p className="text-gray-600">Our AI is identifying ingredients and calculating calories</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex justify-center space-x-4">
              <div className="p-3 bg-emerald-100 rounded-full">
                <Camera className="h-8 w-8 text-emerald-600" />
              </div>
              <div className="p-3 bg-orange-100 rounded-full">
                <Upload className="h-8 w-8 text-orange-600" />
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Upload a food image for AI analysis
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Our enhanced AI model analyzes your food with 90%+ accuracy
              </p>
            </div>
            
            {/* Tips for better recognition */}
            <div className="text-xs text-gray-500 bg-gray-50 rounded-lg p-3 mb-4">
              <h4 className="font-medium text-gray-700 mb-1">Tips for best results:</h4>
              <ul className="space-y-1">
                <li>• Ensure good lighting and clear visibility</li>
                <li>• Center the food in the frame</li>
                <li>• Avoid cluttered backgrounds</li>
                <li>• Include reference objects for size estimation</li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors flex items-center justify-center space-x-2"
              >
                <Upload className="h-4 w-4" />
                <span>Browse Files</span>
              </button>
              
              <button
                onClick={() => cameraInputRef.current?.click()}
                className="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors flex items-center justify-center space-x-2"
              >
                <Camera className="h-4 w-4" />
                <span>Take Photo</span>
              </button>
            </div>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileSelect}
        />
        
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={handleFileSelect}
        />
      </div>
    </div>
  );
};