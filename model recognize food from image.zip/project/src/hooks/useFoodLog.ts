import { useState, useEffect } from 'react';
import { LoggedFood, DailyStats } from '../types/food';

export const useFoodLog = () => {
  const [loggedFoods, setLoggedFoods] = useState<LoggedFood[]>([]);
  const [dailyGoal, setDailyGoal] = useState(2000);

  useEffect(() => {
    const saved = localStorage.getItem('foodLog');
    if (saved) {
      const parsed = JSON.parse(saved);
      setLoggedFoods(parsed.map((item: any) => ({
        ...item,
        timestamp: new Date(item.timestamp)
      })));
    }
    
    const savedGoal = localStorage.getItem('dailyCalorieGoal');
    if (savedGoal) {
      setDailyGoal(parseInt(savedGoal));
    }
  }, []);

  const saveToStorage = (foods: LoggedFood[]) => {
    localStorage.setItem('foodLog', JSON.stringify(foods));
  };

  const addFood = (food: LoggedFood) => {
    const newFoods = [...loggedFoods, food];
    setLoggedFoods(newFoods);
    saveToStorage(newFoods);
  };

  const removeFood = (id: string) => {
    const newFoods = loggedFoods.filter(f => f.id !== id);
    setLoggedFoods(newFoods);
    saveToStorage(newFoods);
  };

  const updateDailyGoal = (goal: number) => {
    setDailyGoal(goal);
    localStorage.setItem('dailyCalorieGoal', goal.toString());
  };

  const getTodaysFoods = (): LoggedFood[] => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return loggedFoods.filter(food => {
      const foodDate = new Date(food.timestamp);
      foodDate.setHours(0, 0, 0, 0);
      return foodDate.getTime() === today.getTime();
    });
  };

  const getDailyStats = (): DailyStats => {
    const todaysFoods = getTodaysFoods();
    
    return todaysFoods.reduce((stats, food) => {
      const weight = food.adjustedWeight || food.recognizedFood.estimatedWeight;
      const calories = Math.round(food.recognizedFood.foodItem.caloriesPerGram * weight);
      const factor = weight / 100;
      
      return {
        totalCalories: stats.totalCalories + calories,
        totalProtein: stats.totalProtein + (food.recognizedFood.foodItem.protein * factor),
        totalCarbs: stats.totalCarbs + (food.recognizedFood.foodItem.carbs * factor),
        totalFat: stats.totalFat + (food.recognizedFood.foodItem.fat * factor),
        totalFiber: stats.totalFiber + (food.recognizedFood.foodItem.fiber * factor),
        goalCalories: dailyGoal
      };
    }, {
      totalCalories: 0,
      totalProtein: 0,
      totalCarbs: 0,
      totalFat: 0,
      totalFiber: 0,
      goalCalories: dailyGoal
    });
  };

  const getFoodsByMeal = () => {
    const todaysFoods = getTodaysFoods();
    return {
      breakfast: todaysFoods.filter(f => f.meal === 'breakfast'),
      lunch: todaysFoods.filter(f => f.meal === 'lunch'),
      dinner: todaysFoods.filter(f => f.meal === 'dinner'),
      snack: todaysFoods.filter(f => f.meal === 'snack')
    };
  };

  return {
    loggedFoods,
    addFood,
    removeFood,
    getTodaysFoods,
    getDailyStats,
    getFoodsByMeal,
    dailyGoal,
    updateDailyGoal
  };
};