import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { ImageUpload } from './components/ImageUpload';
import { FoodResults } from './components/FoodResults';
import { FoodSearch } from './components/FoodSearch';
import { Dashboard } from './components/Dashboard';
import { Settings } from './components/Settings';
import { useFoodLog } from './hooks/useFoodLog';
import { recognizeFood } from './services/foodRecognition';
import { RecognizedFood, LoggedFood } from './types/food';

function App() {
  const [activeTab, setActiveTab] = useState('scan');
  const [isRecognizing, setIsRecognizing] = useState(false);
  const [recognitionResults, setRecognitionResults] = useState<RecognizedFood[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  
  const {
    loggedFoods,
    addFood,
    removeFood,
    getDailyStats,
    getFoodsByMeal,
    dailyGoal,
    updateDailyGoal
  } = useFoodLog();

  const handleImageUpload = async (file: File) => {
    setIsRecognizing(true);
    setUploadedImage(URL.createObjectURL(file));
    
    try {
      const results = await recognizeFood(file);
      setRecognitionResults(results);
    } catch (error) {
      console.error('Food recognition failed:', error);
      setRecognitionResults([]);
    } finally {
      setIsRecognizing(false);
    }
  };

  const handleAddFood = (food: RecognizedFood, meal: string) => {
    const loggedFood: LoggedFood = {
      id: Date.now().toString() + Math.random(),
      recognizedFood: food,
      timestamp: new Date(),
      meal: meal as 'breakfast' | 'lunch' | 'dinner' | 'snack'
    };
    
    addFood(loggedFood);
    
    // Switch to dashboard to show the added food
    setActiveTab('dashboard');
  };

  const handleNewScan = () => {
    setRecognitionResults([]);
    setUploadedImage(null);
  };

  const dailyStats = getDailyStats();
  const foodsByMeal = getFoodsByMeal();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        {activeTab === 'scan' && (
          <div className="space-y-8">
            {recognitionResults.length === 0 ? (
              <div className="space-y-8">
                <div className="text-center">
                  <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    Enhanced AI Food Recognition & Calorie Tracker
                  </h1>
                  <p className="text-lg text-gray-600 mb-8">
                    Advanced AI model with 90%+ accuracy for food identification and calorie estimation
                  </p>
                  <ImageUpload onImageUpload={handleImageUpload} isLoading={isRecognizing} />
                  
                  {uploadedImage && (
                    <div className="mt-6">
                      <img 
                        src={uploadedImage} 
                        alt="Uploaded food" 
                        className="max-w-md mx-auto rounded-xl shadow-lg"
                      />
                    </div>
                  )}
                </div>
                
                <div className="max-w-2xl mx-auto">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-2">Or search manually</h2>
                    <p className="text-gray-600">Can't find what you're looking for? Search our extensive food database</p>
                  </div>
                  <FoodSearch onAddFood={handleAddFood} />
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <button
                    onClick={handleNewScan}
                    className="px-6 py-3 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors mb-4 font-medium"
                  >
                    🔍 Scan Another Food
                  </button>
                </div>
                <FoodResults results={recognitionResults} onAddFood={handleAddFood} />
              </div>
            )}
          </div>
        )}

        {activeTab === 'dashboard' && (
          <Dashboard 
            dailyStats={dailyStats}
            foodsByMeal={foodsByMeal}
            onRemoveFood={removeFood}
          />
        )}

        {activeTab === 'settings' && (
          <Settings
            dailyGoal={dailyGoal}
            onUpdateGoal={updateDailyGoal}
            loggedFoods={loggedFoods}
          />
        )}
      </main>
    </div>
  );
}

export default App;