export interface FoodItem {
  id: string;
  name: string;
  caloriesPerGram: number;
  protein: number; // grams per 100g
  carbs: number; // grams per 100g
  fat: number; // grams per 100g
  fiber: number; // grams per 100g
  category: string;
  commonPortionSizes: PortionSize[];
}

export interface PortionSize {
  name: string;
  grams: number;
}

export interface RecognizedFood {
  foodItem: FoodItem;
  confidence: number;
  estimatedWeight: number; // in grams
  calories: number;
  nutrition: NutritionInfo;
}

export interface NutritionInfo {
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
}

export interface LoggedFood {
  id: string;
  recognizedFood: RecognizedFood;
  timestamp: Date;
  meal: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  adjustedWeight?: number;
}

export interface DailyStats {
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  goalCalories: number;
}